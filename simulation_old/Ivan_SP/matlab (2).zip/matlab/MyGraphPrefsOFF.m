
%% Restore MATLAB default graphics settings

set(0, 'DefaultAxesFontSize','remove')

set(0, 'DefaultLineLineWidth','remove')

set(0,'DefaultFigureColor', 'remove')

set(0, 'DefaultAxesTickDir', 'remove')
