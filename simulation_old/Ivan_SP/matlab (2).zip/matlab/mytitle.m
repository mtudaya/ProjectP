function h = mytitle(txt)

h = text(0.5, 0.98, txt, 'units', 'normalized', 'horizontalalignment', 'center', 'verticalalignment', 'top', 'fontsize', 16);

% Ivan Selesnick
% NYU-Poly
% selesi@poly.edu
